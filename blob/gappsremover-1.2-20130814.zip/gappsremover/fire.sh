#!/system/bin/sh
SA=/system/app
BB=busybox
$BB mount -o remount,rw /system
echo "Google Apps Remover v1.2 [2013.08.14.15.42.43]"
echo "by CidDeamon"
echo "All rights reserved. Copying, republishing, modyfing forbidden!!!"
for i in `cat debloater0.h`
do
	if [ -f /system/${i} ]
	then
		$BB rm /system/${i}
	fi
done
for k in `cat debloater1.h`
do
	if [ -f $SA/${k} ]
	then
		$BB rm $SA/${k}
		$BB cp /sdcard/gappsremover/${k} $SA/
		$BB chmod 644 $SA/${k}
	fi
done
$BB cp /sdcard/gappsremover/CalendarManager.apk $SA/
$BB chmod 644 $SA/*.apk
echo "Done. Make factory reset NOW!"
$BB mount -o remount,ro /system
exit 0
